from pydantic import BaseModel, Field
from typing import Optional

class NeighbourhoodSignals(BaseModel):
    neighbourhood:         str
    zone_type:             str   = Field(..., description="commercial | residential | mixed")
    transit_score:         float = Field(..., ge=0, le=100)
    school_rating:         float = Field(..., ge=0, le=10)
    crime_index:           float = Field(..., ge=0, le=100)
    walkability:           float = Field(..., ge=0, le=100)
    median_income:         float = Field(..., gt=0)
    vacancy_rate:          float = Field(..., ge=0, le=1)
    proximity_cbd_km:      float = Field(..., gt=0)
    n_permits_residential: int   = Field(..., ge=0)
    n_permits_commercial:  int   = Field(..., ge=0)
    permit_value_m:        float = Field(..., ge=0)
    large_development_flag:int   = Field(..., ge=0, le=1)
    new_business_licenses: int   = Field(..., ge=0)
    net_business_growth:   int
    zoning_change_flag:    int   = Field(..., ge=0, le=1)
    planning_applications: int   = Field(..., ge=0)
    infrastructure_invest: float = Field(..., ge=0)
    news_positive_score:   float = Field(..., ge=0, le=1)
    news_volume:           int   = Field(..., ge=0)
    investment_news_flag:  int   = Field(..., ge=0, le=1)
    days_on_market:        float = Field(..., gt=0)
    listing_price_change:  float
    foreclosure_rate:      float = Field(..., ge=0, le=1)
    month_of_year:         int   = Field(..., ge=1, le=12)

class GrowthForecast(BaseModel):
    neighbourhood:          str
    growth_probability:     float
    growth_tier:            str
    predicted_rent_trend:   str
    gentrification_score:   float
    investment_activity:    float
    liveability_score:      float
    top_growth_drivers:     list
    top_risk_factors:       list
    recommended_for:        str