import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schema import NeighbourhoodSignals, GrowthForecast

app = FastAPI(
    title="Hyper-Local Economic Signal Forecaster",
    description="Predict neighbourhood rent growth using local economic signals",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

model = xgb.XGBClassifier()
model.load_model("growth_model.json")

le_zone = joblib.load("le_zone.joblib")
le_nbr  = joblib.load("le_nbr.joblib")

with open("growth_metadata.json") as f:
    metadata = json.load(f)

with open("neighbourhood_scores.json") as f:
    nbr_scores = json.load(f)

FEATURES = metadata["features"]


def safe_encode(encoder, value, known):
    return int(encoder.transform([value])[0]) if value in known else 0


def engineer_features(data: dict) -> pd.DataFrame:
    d = data.copy()
    d['zone_enc'] = safe_encode(le_zone, data['zone_type'], metadata['zone_types'])
    d['nbr_enc']  = safe_encode(le_nbr, data['neighbourhood'], metadata['neighbourhoods'])

    for col in ['n_permits_residential','net_business_growth',
                'news_positive_score','permit_value_m','days_on_market']:
        d[f'{col}_3m_avg'] = data[col]
        d[f'{col}_trend']  = 0.0

    d['gentrification_score'] = (
        data['net_business_growth'] / 10 * 0.25 +
        data['news_positive_score'] * 0.25 +
        data['permit_value_m'] / 20 * 0.20 +
        (1 - data['vacancy_rate']) * 0.15 +
        data['transit_score'] / 100 * 0.15
    )
    d['investment_activity'] = (
        data['n_permits_commercial'] * 2 +
        data['large_development_flag'] * 5 +
        data['zoning_change_flag'] * 3 +
        data['investment_news_flag'] * 2 +
        data['planning_applications']
    )
    d['liveability_score'] = (
        data['transit_score'] / 100 * 0.3 +
        data['walkability'] / 100 * 0.3 +
        data['school_rating'] / 10 * 0.2 +
        (1 - data['crime_index'] / 100) * 0.2
    )

    return pd.DataFrame([d])[FEATURES]


def get_growth_tier(prob):
    if prob >= 0.70: return "Hot"
    if prob >= 0.50: return "High"
    if prob >= 0.30: return "Medium"
    return "Low"


def get_rent_trend(prob):
    if prob >= 0.70: return "Strong upward — expect 8-15% increase"
    if prob >= 0.50: return "Moderate upward — expect 5-8% increase"
    if prob >= 0.30: return "Mild upward — expect 2-5% increase"
    return "Stable or declining — expect 0-2% change"


def get_recommendation(tier):
    recs = {
        "Hot":    "Investors: buy now before appreciation. Renters: lock in long-term lease immediately.",
        "High":   "Investors: strong opportunity. Renters: negotiate lease renewal soon.",
        "Medium": "Investors: monitor closely. Renters: consider 12-month lease.",
        "Low":    "Investors: wait for stronger signals. Renters: good time to negotiate."
    }
    return recs[tier]


@app.get("/")
def root():
    return {"service": "Hyper-Local Economic Signal Forecaster",
            "version": metadata["version"],
            "model_auc": metadata["model_auc"]}


@app.post("/forecast", response_model=GrowthForecast)
def forecast_growth(signals: NeighbourhoodSignals):
    try:
        data = signals.model_dump()
        X    = engineer_features(data)

        prob = float(model.predict_proba(X)[0][1])
        tier = get_growth_tier(prob)

        dmatrix  = xgb.DMatrix(X, feature_names=FEATURES)
        contribs = model.get_booster().predict(dmatrix, pred_contribs=True)
        vals     = contribs[0][:-1]

        pairs    = sorted(zip(FEATURES, vals), key=lambda x: abs(x[1]), reverse=True)
        drivers  = [{"signal": f, "impact": round(float(v), 4)}
                    for f, v in pairs if v > 0][:4]
        risks    = [{"signal": f, "drag": round(float(abs(v)), 4)}
                    for f, v in pairs if v < 0][:3]

        return GrowthForecast(
            neighbourhood=signals.neighbourhood,
            growth_probability=round(prob, 4),
            growth_tier=tier,
            predicted_rent_trend=get_rent_trend(prob),
            gentrification_score=round(float(X['gentrification_score'].iloc[0]), 4),
            investment_activity=round(float(X['investment_activity'].iloc[0]), 4),
            liveability_score=round(float(X['liveability_score'].iloc[0]), 4),
            top_growth_drivers=drivers,
            top_risk_factors=risks,
            recommended_for=get_recommendation(tier)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/neighbourhoods")
def list_neighbourhoods():
    return nbr_scores


@app.get("/neighbourhoods/hot")
def hot_neighbourhoods():
    return [n for n in nbr_scores if n['growth_tier'] == 'Hot']


@app.get("/model/info")
def model_info():
    return metadata