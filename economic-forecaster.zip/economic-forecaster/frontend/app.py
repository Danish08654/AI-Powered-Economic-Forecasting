import streamlit as st
import requests
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

API_URL = "http://localhost:8000"

st.set_page_config(
    page_title="Economic Signal Forecaster",
    page_icon="🏙️",
    layout="wide"
)

st.title("🏙️ Hyper-Local Economic Signal Forecaster")

ZONES = ['commercial', 'residential', 'mixed']
NBRS  = [
    'Downtown Core','East Village','Williamsburg','Long Island City',
    'Bushwick','Astoria','Harlem','Greenpoint','Midtown','Flushing',
    'Bronx Hub','Bay Ridge','Jamaica','Forest Hills','Crown Heights'
]

tab1, tab2, tab3 = st.tabs([
    "🔍 Forecast Neighbourhood",
    "🗺️ City Map",
    "📊 All Neighbourhoods"
])

with tab1:
    col_a, col_b = st.columns([1, 1])

    with col_a:
        st.subheader("Neighbourhood Signals")

        neighbourhood = st.selectbox("Neighbourhood", NBRS)
        zone_type     = st.selectbox("Zone Type", ZONES)
        month_of_year = st.slider("Month", 1, 12, 5)

        st.markdown("**🏗️ Building & Planning**")
        permits_res  = st.slider("Residential Permits", 0, 30, 8)
        permits_com  = st.slider("Commercial Permits", 0, 15, 3)
        permit_value = st.number_input("Permit Value ($M)", 0.0, 50.0, 5.0)
        large_dev    = st.checkbox("Large Development (>$15M)", False)
        zoning_chg   = st.checkbox("Zoning Change Filed", False)
        plan_apps    = st.slider("Planning Applications", 0, 20, 3)
        infra_invest = st.slider("Infrastructure Investment ($M)", 0.0, 20.0, 2.0)

        st.markdown("**🏪 Business Activity**")
        new_licenses = st.slider("New Business Licenses", 0, 25, 6)
        net_biz      = st.slider("Net Business Growth", -10, 20, 3)
        invest_news  = st.checkbox("Investment News Published", False)
        news_score   = st.slider("News Sentiment (0=negative, 1=positive)", 0.0, 1.0, 0.55, 0.05)
        news_vol     = st.slider("News Volume (30d)", 0, 50, 12)

        st.markdown("**🏠 Real Estate**")
        days_market  = st.slider("Days on Market", 5.0, 90.0, 35.0, 1.0)
        price_chg    = st.slider("Listing Price Change %", -10.0, 15.0, 1.5, 0.5)
        foreclosure  = st.slider("Foreclosure Rate", 0.0, 0.15, 0.02, 0.005)
        vacancy      = st.slider("Vacancy Rate", 0.02, 0.20, 0.06, 0.01)

        st.markdown("**🌆 Neighbourhood Profile**")
        transit      = st.slider("Transit Score", 40, 99, 75)
        school       = st.slider("School Rating", 3.0, 10.0, 6.5, 0.1)
        crime        = st.slider("Crime Index", 10, 80, 35)
        walk         = st.slider("Walkability", 50, 99, 78)
        income       = st.number_input("Median Income ($)", 30000, 150000, 65000, step=1000)
        cbd_km       = st.slider("Distance to CBD (km)", 1.0, 20.0, 5.0, 0.5)

        forecast_btn = st.button("Forecast Growth",
                                  type="primary", use_container_width=True)

    with col_b:
        if forecast_btn:
            payload = {
                "neighbourhood":         neighbourhood,
                "zone_type":             zone_type,
                "month_of_year":         month_of_year,
                "transit_score":         float(transit),
                "school_rating":         school,
                "crime_index":           float(crime),
                "walkability":           float(walk),
                "median_income":         float(income),
                "vacancy_rate":          vacancy,
                "proximity_cbd_km":      cbd_km,
                "n_permits_residential": permits_res,
                "n_permits_commercial":  permits_com,
                "permit_value_m":        permit_value,
                "large_development_flag":int(large_dev),
                "new_business_licenses": new_licenses,
                "net_business_growth":   net_biz,
                "zoning_change_flag":    int(zoning_chg),
                "planning_applications": plan_apps,
                "infrastructure_invest": infra_invest,
                "news_positive_score":   news_score,
                "news_volume":           news_vol,
                "investment_news_flag":  int(invest_news),
                "days_on_market":        days_market,
                "listing_price_change":  price_chg,
                "foreclosure_rate":      foreclosure,
            }

            with st.spinner("Forecasting..."):
                try:
                    resp   = requests.post(f"{API_URL}/forecast", json=payload)
                    result = resp.json()
                except Exception as e:
                    st.error(f"API error: {e}")
                    st.stop()

            tier_colors = {
                "Hot":"#e74c3c","High":"#e67e22",
                "Medium":"#f39c12","Low":"#27ae60"
            }
            tier  = result['growth_tier']
            color = tier_colors.get(tier, "gray")

            st.markdown(
                f"<div style='background:{color};padding:16px;"
                f"border-radius:10px;text-align:center;"
                f"color:white;font-size:20px;font-weight:600'>"
                f"GROWTH TIER: {tier} — "
                f"{result['growth_probability']*100:.1f}% Probability"
                f"</div>", unsafe_allow_html=True
            )
            st.markdown("")

            c1, c2, c3 = st.columns(3)
            c1.metric("Growth Probability",   f"{result['growth_probability']*100:.1f}%")
            c2.metric("Gentrification Score",  f"{result['gentrification_score']:.3f}")
            c3.metric("Liveability Score",     f"{result['liveability_score']:.3f}")

            st.info(f"**Trend:** {result['predicted_rent_trend']}")
            st.success(f"**Recommendation:** {result['recommended_for']}")

            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=round(result['growth_probability'] * 100, 1),
                number={"suffix": "%"},
                gauge={
                    "axis": {"range": [0, 100]},
                    "bar":  {"color": color},
                    "steps": [
                        {"range":[0,30],  "color":"#d5f5e3"},
                        {"range":[30,50], "color":"#fef9e7"},
                        {"range":[50,70], "color":"#fdebd0"},
                        {"range":[70,100],"color":"#fadbd8"},
                    ]
                }
            ))
            fig.update_layout(height=250, margin=dict(t=20,b=10))
            st.plotly_chart(fig, use_container_width=True)

            col_d, col_r = st.columns(2)
            with col_d:
                st.markdown("**🚀 Growth Drivers**")
                for d in result['top_growth_drivers']:
                    st.markdown(f"- `{d['signal']}` +{d['impact']:.4f}")
            with col_r:
                st.markdown("**⚠️ Risk Factors**")
                for r in result['top_risk_factors']:
                    st.markdown(f"- `{r['signal']}` -{r['drag']:.4f}")
        else:
            st.info("Configure signals and click **Forecast Growth**.")

with tab2:
    st.subheader("Neighbourhood Growth Map")
    try:
        nbr_data = requests.get(f"{API_URL}/neighbourhoods").json()
        nbr_df   = pd.DataFrame(nbr_data)

        fig = px.scatter_mapbox(
            nbr_df,
            lat="lat", lon="lon",
            size="growth_prob",
            color="growth_tier",
            hover_name="neighbourhood",
            hover_data={"growth_prob": ":.1%",
                       "current_rent": ":,.0f",
                       "gentrification_score":":.3f"},
            color_discrete_map={
                "Hot":"#e74c3c","High":"#e67e22",
                "Medium":"#f1c40f","Low":"#27ae60"
            },
            mapbox_style="carto-positron",
            zoom=10,
            center={"lat":40.730,"lon":-73.935},
            size_max=30,
            title="Neighbourhood Growth Forecast Map"
        )
        fig.update_layout(height=500, margin=dict(t=40,b=10))
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Could not load map: {e}")

with tab3:
    st.subheader("All Neighbourhood Rankings")
    try:
        nbr_data = requests.get(f"{API_URL}/neighbourhoods").json()
        nbr_df   = pd.DataFrame(nbr_data).sort_values(
            'growth_prob', ascending=False
        )

        fig = px.bar(
            nbr_df,
            x='neighbourhood', y='growth_prob',
            color='growth_tier',
            color_discrete_map={
                "Hot":"#e74c3c","High":"#e67e22",
                "Medium":"#f1c40f","Low":"#27ae60"
            },
            title="Growth Probability by Neighbourhood",
            labels={'growth_prob':'Growth Probability','neighbourhood':''}
        )
        fig.update_layout(xaxis_tickangle=-45, height=400)
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(
            nbr_df[['neighbourhood','zone_type','growth_prob',
                    'growth_tier','current_rent','gentrification_score',
                    'liveability_score','investment_activity']],
            use_container_width=True
        )
    except Exception as e:
        st.error(f"Could not load data: {e}")